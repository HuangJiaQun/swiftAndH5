//
//  WebViewControllerTwo.swift
//  ios和h5交互
//
//  Created by 黄嘉群 on 2020/11/12.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import UIKit
import WebKit
class WebViewControllerTwo: UIViewController,WKScriptMessageHandler {
    var str:NSMutableString?
    
    deinit {
        wkView.configuration.userContentController.removeAllUserScripts()
    }
    
    lazy var wkView: WKWebView = {
        
        let config = WKWebViewConfiguration()
        // 设置偏好设置
        config.preferences = WKPreferences()
        // 默认为0
        config.preferences.minimumFontSize = 10
        // 默认认为YES
        config.preferences.javaScriptEnabled = true
        // 在iOS上默认为NO，表示不能自动通过窗口打开
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        // web内容处理池
        config.processPool = WKProcessPool()
        // 通过JS与webview内容交互
        config.userContentController = WKUserContentController()
        // 注入JS对象名称AppModel，当JS通过AppModel来调用时，
        // 我们可以在WKScriptMessageHandler代理中接收到
        config.userContentController.add(self, name: "H5toiOS_NoValue")
        config.userContentController.add(self, name: "H5toiOS_IntValue")
        config.allowsInlineMediaPlayback = true
        if #available(iOS 9.0, *) {
            config.allowsAirPlayForMediaPlayback = true
        }
        let wkView = WKWebView.init(frame:CGRect(x: 0, y: 44, width:SCREEN_WIDTH,height: SCREEN_HEIGHT-44), configuration: config)
        wkView.allowsBackForwardNavigationGestures = true
        return wkView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.str = NSMutableString.init()
        self.title = "two"
        self.view.backgroundColor = .white
        
//        let bundlePath = Bundle.main.path(forResource: "index", ofType: "html") ?? ""
////        let bundlePath = Bundle.main.bundlePath
////        let filePath = "file://\(bundlePath)/index.html"
//
//
//        guard let request = URLRequest(url: bundlePath) else {
//            return
//        }
        
        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            let request = URLRequest(url: url)
            wkView.load(request)
        }
//        wkView.navigationDelegate = self // web视图的导航委托。
//        wkView.uiDelegate = self
        self.view.addSubview(wkView)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        NSLog("js 回调:\(message.body)")
        if message.name == "H5toiOS_NoValue" {
            self.str?.append("H5没有传值\n")
        }else if message.name == "H5toiOS_IntValue" {
            let i:Int = message.body as! Int
            self.str?.append(String(format: "%@\n",i))
        }
        print(self.str ?? "")
    }

}
