// JavaScript Document
function H5WithNoValue() {
	window.webkit.messageHandlers.H5toiOS_NoValue.postMessage(null);
}

function H5WithIntValue() {
	window.webkit.messageHandlers.H5toiOS_IntValue.postMessage(100);
}

function H5WithStringValue() {
	window.webkit.messageHandlers.H5toiOS_StringValue.postMessage("宜达互联,hello world!");
}

function H5WithArrayValue() {
	var ary = ["iOS","Java","JavaScript","英语"];
	window.webkit.messageHandlers.H5toiOS_ArrayValue.postMessage(ary);
}

function H5WithJSONValue() {
	var yida = {
		"company":"宜达互联科技",
		"kecheng":["iOS","Java","Html5","css3","JS"],
		"teacher":{
			"name":"钱老师",
			"age":31,
			"sex":"男"
		}
	};
	window.webkit.messageHandlers.H5toiOS_JSONValue.postMessage(yida);
}

function removeiOSText() {
	window.webkit.messageHandlers.CleariOSText.postMessage(null);
}
