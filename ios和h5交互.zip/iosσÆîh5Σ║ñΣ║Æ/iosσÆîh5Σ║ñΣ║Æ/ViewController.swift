//
//  ViewController.swift
//  ios和h5交互
//
//  Created by 黄嘉群 on 2020/11/11.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        #if true
        let web:WebViewController = WebViewController()
        self.navigationController?.pushViewController(web, animated: true)
        #else
        let web:WebViewControllerTwo = WebViewControllerTwo()
        self.navigationController?.pushViewController(web, animated: true)
        #endif
        // Do any additional setup after loading the view.
    }


}

