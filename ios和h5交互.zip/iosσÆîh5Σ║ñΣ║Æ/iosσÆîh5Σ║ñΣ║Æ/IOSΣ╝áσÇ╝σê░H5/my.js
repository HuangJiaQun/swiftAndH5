// JavaScript Document
function iOSWithNoValue() {
    var span = document.getElementById("span-showios-novalue");
    span.innerHTML = "iOS没有传值";
}

function iOSWithIntValue(a) {
    var span = document.getElementById("span-showios-intvalue");
    span.innerHTML = a;
}

function iOSWithStringValue(b) {
    var span = document.getElementById("span-showios-stringvalue");
    span.innerHTML = b;
}


function iOSWithArrayValue(obj) {
    var span = document.getElementById("span-showios-arrayvalue");
    var ary = JSON.parse(obj);
    var str = "课程内容：";
    for(var i = 0; i < ary.length; i++) {
        str += ary[i]+" ";
    }
    span.innerHTML = str;
}

function iOSWithDictionaryValue(obj) {
    var span = document.getElementById("span-showios-dictionaryvalue");
    /*
     {
     @"name":@"黄小明",
     @"age":@32,
     @"sex":@"男",
     @"address":@"深圳市福田区车公庙"
     }
     */
    var stu = JSON.parse(obj);//js里没有字典，只有json对象
    span.innerHTML = "学生信息如下：<br/>姓名："+stu.name+"<br/>年龄："+stu.age+"<br/>性别："+stu.sex+"<br/>住址："+stu.address;
}

function iOSWithJSONValue(obj) {
    var span = document.getElementById("span-showios-jsonvalue");
    /*
     {
     "company":"宜达互联科技",
     "kecheng":["iOS","Java","Html5","css3","JS"],
     "teacher":{
     "name":"钱老师",
     "age":31,
     "sex":"男"
     }
     }
     */
    var yida = JSON.parse(obj);
    var str = "公司名称："+yida.company;
    str += "<br/>授课老师："+yida.teacher.name+" "+yida.teacher.sex+" "+yida.teacher.age;
    str += "<br/>课程：";
    var kcAry = yida.kecheng;
    for(var i = 0; i < kcAry.length; i++) {
        str += kcAry[i]+",";
    }
    span.innerHTML = str.substr(0,str.length-1);
}


function removeAllValue() {
    var spanAry = document.getElementsByTagName("span");
    for(var i = 0; i < spanAry.length; i++) {
        var span = spanAry[i];
        if (span.id != "showios") {
            span.innerHTML = "";
        }
    }
}

