//
//  WebViewController.swift
//  ios和h5交互
//
//  Created by 黄嘉群 on 2020/11/12.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import UIKit
import WebKit
//MARK: - 屏幕相关
let SCREEN_WIDTH: CGFloat       = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT: CGFloat      = UIScreen.main.bounds.size.height

class WebViewController: UIViewController,WKNavigationDelegate,WKUIDelegate {
    
    deinit {
    }
    
    lazy var wkView: WKWebView = {
        
        let config = WKWebViewConfiguration()
        // 设置偏好设置
        config.preferences = WKPreferences()
        // 默认为0
        config.preferences.minimumFontSize = 10
        // 默认认为YES
        config.preferences.javaScriptEnabled = true
        // 在iOS上默认为NO，表示不能自动通过窗口打开
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        // web内容处理池
        config.processPool = WKProcessPool()
        // 通过JS与webview内容交互
        config.userContentController = WKUserContentController()
        // 注入JS对象名称AppModel，当JS通过AppModel来调用时，
        // 我们可以在WKScriptMessageHandler代理中接收到
        config.allowsInlineMediaPlayback = true
        if #available(iOS 9.0, *) {
            config.allowsAirPlayForMediaPlayback = true
        }
        let wkView = WKWebView.init(frame:CGRect(x: 0, y: 44, width:SCREEN_WIDTH,height: SCREEN_HEIGHT-44), configuration: config)
        wkView.allowsBackForwardNavigationGestures = true
        wkView.uiDelegate=self
        wkView.navigationDelegate = self
        return wkView
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="one"

        self.view.addSubview(wkView)
        if let url = Bundle.main.url(forResource: "my", withExtension: "html") {
            let request = URLRequest(url: url)
            wkView.load(request)
        }
    }
    
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        //web加载好了才有左边按钮
        let leftBtton = UIButton()
        leftBtton.setTitle("传值", for: .normal)
        leftBtton.addTarget(self, action: #selector(goBackMenu), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem
            = UIBarButtonItem(customView: leftBtton)
        
    }
    
    @objc func goBackMenu() {
        let js:String = String(format: "iOSWithStringValue('%@');", "宜达互联,hello world!")
        wkView.evaluateJavaScript(js, completionHandler: { (response, error) in
            if !(error != nil){
                print("成功")
            }else{
                print("失败")
            }
        })
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
